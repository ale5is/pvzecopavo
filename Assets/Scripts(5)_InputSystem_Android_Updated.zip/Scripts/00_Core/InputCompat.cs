using UnityEngine;
using UnityEngine.InputSystem;

public static class InputCompat
{
    public static Vector3 mousePosition
    {
        get
        {
            if (Mouse.current != null)
                return Mouse.current.position.ReadValue();

            if (Touchscreen.current != null)
                return Touchscreen.current.primaryTouch.position.ReadValue();

            return Vector3.zero;
        }
    }

    public static int touchCount
    {
        get
        {
            if (Touchscreen.current == null)
                return 0;

            int count = 0;
            foreach (TouchControl touch in Touchscreen.current.touches)
            {
                if (touch.press.isPressed)
                    count++;
            }
            return count;
        }
    }

    public static Touch GetTouch(int index)
    {
        if (Touchscreen.current == null)
            return default;

        int activeIndex = 0;
        foreach (TouchControl touch in Touchscreen.current.touches)
        {
            if (!touch.press.isPressed)
                continue;

            if (activeIndex == index)
            {
                TouchPhase phase = TouchPhase.Moved;
                if (touch.press.wasPressedThisFrame)
                    phase = TouchPhase.Began;
                else if (touch.press.wasReleasedThisFrame)
                    phase = TouchPhase.Ended;

                return new Touch
                {
                    fingerId = activeIndex,
                    position = touch.position.ReadValue(),
                    phase = phase,
                    deltaPosition = touch.delta.ReadValue()
                };
            }
            activeIndex++;
        }
        return default;
    }

    public static float GetAxis(string axisName)
    {
        if (axisName == "Mouse ScrollWheel")
        {
            if (Mouse.current == null)
                return 0f;
            return Mouse.current.scroll.ReadValue().y / 120f;
        }

        if (axisName == "Horizontal")
            return KeyboardAxis(Key.LeftArrow, Key.RightArrow);

        if (axisName == "Vertical")
            return KeyboardAxis(Key.DownArrow, Key.UpArrow);

        return 0f;
    }

    private static float KeyboardAxis(Key negative, Key positive)
    {
        if (Keyboard.current == null)
            return 0f;

        float value = 0f;
        if (Keyboard.current[negative].isPressed)
            value -= 1f;
        if (Keyboard.current[positive].isPressed)
            value += 1f;
        return value;
    }

    public static bool GetKey(KeyCode keyCode)
    {
        return TryGetKeyControl(keyCode, out KeyControl control) &&
               control.isPressed;
    }

    public static bool GetKeyDown(KeyCode keyCode)
    {
        return TryGetKeyControl(keyCode, out KeyControl control) &&
               control.wasPressedThisFrame;
    }

    public static bool GetKeyUp(KeyCode keyCode)
    {
        return TryGetKeyControl(keyCode, out KeyControl control) &&
               control.wasReleasedThisFrame;
    }

    private static bool TryGetKeyControl(
        KeyCode keyCode,
        out KeyControl control)
    {
        control = null;

        if (Keyboard.current == null)
            return false;

        if (!TryConvertKey(keyCode, out Key key))
            return false;

        control = Keyboard.current[key];
        return control != null;
    }

    public static bool GetMouseButtonDown(int button)
    {
        if (button == 0)
        {
            if (Mouse.current != null &&
                Mouse.current.leftButton.wasPressedThisFrame)
                return true;

            return Touchscreen.current != null &&
                   Touchscreen.current.primaryTouch.press.wasPressedThisFrame;
        }

        if (button == 1)
            return Mouse.current != null &&
                   Mouse.current.rightButton.wasPressedThisFrame;

        if (button == 2)
            return Mouse.current != null &&
                   Mouse.current.middleButton.wasPressedThisFrame;

        return false;
    }

    public static bool GetMouseButtonUp(int button)
    {
        if (button == 0)
        {
            if (Mouse.current != null &&
                Mouse.current.leftButton.wasReleasedThisFrame)
                return true;

            return Touchscreen.current != null &&
                   Touchscreen.current.primaryTouch.press.wasReleasedThisFrame;
        }

        if (button == 1)
            return Mouse.current != null &&
                   Mouse.current.rightButton.wasReleasedThisFrame;

        if (button == 2)
            return Mouse.current != null &&
                   Mouse.current.middleButton.wasReleasedThisFrame;

        return false;
    }

    public static bool GetMouseButton(int button)
    {
        if (button == 0)
        {
            if (Mouse.current != null &&
                Mouse.current.leftButton.isPressed)
                return true;

            return Touchscreen.current != null &&
                   Touchscreen.current.primaryTouch.press.isPressed;
        }

        if (button == 1)
            return Mouse.current != null &&
                   Mouse.current.rightButton.isPressed;

        if (button == 2)
            return Mouse.current != null &&
                   Mouse.current.middleButton.isPressed;

        return false;
    }

    private static bool TryConvertKey(
        KeyCode keyCode,
        out Key key)
    {
        switch (keyCode)
        {
            case KeyCode.A: key = Key.A; return true;
            case KeyCode.B: key = Key.B; return true;
            case KeyCode.C: key = Key.C; return true;
            case KeyCode.D: key = Key.D; return true;
            case KeyCode.E: key = Key.E; return true;
            case KeyCode.F: key = Key.F; return true;
            case KeyCode.G: key = Key.G; return true;
            case KeyCode.H: key = Key.H; return true;
            case KeyCode.I: key = Key.I; return true;
            case KeyCode.J: key = Key.J; return true;
            case KeyCode.K: key = Key.K; return true;
            case KeyCode.L: key = Key.L; return true;
            case KeyCode.M: key = Key.M; return true;
            case KeyCode.N: key = Key.N; return true;
            case KeyCode.O: key = Key.O; return true;
            case KeyCode.P: key = Key.P; return true;
            case KeyCode.Q: key = Key.Q; return true;
            case KeyCode.R: key = Key.R; return true;
            case KeyCode.S: key = Key.S; return true;
            case KeyCode.T: key = Key.T; return true;
            case KeyCode.U: key = Key.U; return true;
            case KeyCode.V: key = Key.V; return true;
            case KeyCode.W: key = Key.W; return true;
            case KeyCode.X: key = Key.X; return true;
            case KeyCode.Y: key = Key.Y; return true;
            case KeyCode.Z: key = Key.Z; return true;
            case KeyCode.Alpha0: key = Key.Digit0; return true;
            case KeyCode.Alpha1: key = Key.Digit1; return true;
            case KeyCode.Alpha2: key = Key.Digit2; return true;
            case KeyCode.Alpha3: key = Key.Digit3; return true;
            case KeyCode.Alpha4: key = Key.Digit4; return true;
            case KeyCode.Alpha5: key = Key.Digit5; return true;
            case KeyCode.Alpha6: key = Key.Digit6; return true;
            case KeyCode.Alpha7: key = Key.Digit7; return true;
            case KeyCode.Alpha8: key = Key.Digit8; return true;
            case KeyCode.Alpha9: key = Key.Digit9; return true;
            case KeyCode.Keypad0: key = Key.Numpad0; return true;
            case KeyCode.Keypad1: key = Key.Numpad1; return true;
            case KeyCode.Keypad2: key = Key.Numpad2; return true;
            case KeyCode.Keypad3: key = Key.Numpad3; return true;
            case KeyCode.Keypad4: key = Key.Numpad4; return true;
            case KeyCode.Keypad5: key = Key.Numpad5; return true;
            case KeyCode.Keypad6: key = Key.Numpad6; return true;
            case KeyCode.Keypad7: key = Key.Numpad7; return true;
            case KeyCode.Keypad8: key = Key.Numpad8; return true;
            case KeyCode.Keypad9: key = Key.Numpad9; return true;
            case KeyCode.KeypadEnter: key = Key.NumpadEnter; return true;
            case KeyCode.Space: key = Key.Space; return true;
            case KeyCode.Escape: key = Key.Escape; return true;
            case KeyCode.Return: key = Key.Enter; return true;
            case KeyCode.Comma: key = Key.Comma; return true;
            case KeyCode.Period: key = Key.Period; return true;
            case KeyCode.Slash: key = Key.Slash; return true;
            case KeyCode.UpArrow: key = Key.UpArrow; return true;
            case KeyCode.DownArrow: key = Key.DownArrow; return true;
            case KeyCode.LeftArrow: key = Key.LeftArrow; return true;
            case KeyCode.RightArrow: key = Key.RightArrow; return true;
            case KeyCode.LeftShift: key = Key.LeftShift; return true;
            case KeyCode.RightShift: key = Key.RightShift; return true;
            case KeyCode.LeftControl: key = Key.LeftCtrl; return true;
            case KeyCode.RightControl: key = Key.RightCtrl; return true;
            case KeyCode.LeftAlt: key = Key.LeftAlt; return true;
            case KeyCode.RightAlt: key = Key.RightAlt; return true;
            default:
                key = Key.None;
                return false;
        }
    }
}
